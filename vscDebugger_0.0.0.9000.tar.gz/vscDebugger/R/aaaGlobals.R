# create environment for global data used by package functions
.packageEnv <- new.env()